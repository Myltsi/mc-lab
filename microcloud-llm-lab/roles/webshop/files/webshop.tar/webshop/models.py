from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash,check_password_hash
db=SQLAlchemy()
class User(db.Model):
 id=db.Column(db.Integer,primary_key=True)
 username=db.Column(db.String(100),unique=True,nullable=False)
 password_hash=db.Column(db.String(255),nullable=False)
 def set_password(self,p): self.password_hash=generate_password_hash(p)
 def verify_password(self,p): return check_password_hash(self.password_hash,p)
class Order(db.Model):
 id=db.Column(db.Integer,primary_key=True)
 user_id=db.Column(db.Integer,db.ForeignKey('user.id'))
 total=db.Column(db.Float)
 items=db.Column(db.Text)
