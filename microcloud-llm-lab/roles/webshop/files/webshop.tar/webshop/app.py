from flask import Flask,render_template,request,redirect,url_for,session,flash
import logging
from models import db,User,Order
app=Flask(__name__)
app.config['SECRET_KEY']='change-me'
app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///webshop.db'
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s"
)
db.init_app(app)
with app.app_context(): db.create_all()
PRODUCTS = [
    {
        "id": 1,
        "name": "Screaming Teacup",
        "price": 19.99,
        "image": "images/screaming_teacup.png",
        "description": "Because sometimes your tea just needs to be heard."
    },
    {
        "id": 2,
        "name": "Certified Dragon Tooth",
        "price": 299.95,
        "image": "images/dragon_tooth.png",
        "description": "Genuine. Totally real. Probably."
    },
    {
        "id": 3,
        "name": "Left-Handed Hammer",
        "price": 44.90,
        "image": "images/left_handed_hammer.png",
        "description": "Finally, a hammer that understands you."
    },
    {
        "id": 4,
        "name": "Invisible Umbrella",
        "price": 89.00,
        "image": "images/invisible_umbrella.png",
        "description": "Stay dry in style. Sort of."
    },
    {
        "id": 5,
        "name": "Pocket Volcano",
        "price": 129.50,
        "image": "images/pocket_volcano.png",
        "description": "Tiny eruptions, big adventures."
    },
    {
        "id": 6,
        "name": "Quantum Socks",
        "price": 24.95,
        "image": "images/quantum_socks.png",
        "description": "At the same time warm, cool, and somewhere else."
    }
]

def current_user():
 uid=session.get('user_id'); return User.query.get(uid) if uid else None
@app.route('/')
def index(): return render_template('index.html',products=PRODUCTS)
@app.route('/register',methods=['GET','POST'])
def register():
 if request.method=='POST':
  if User.query.filter_by(username=request.form['username']).first(): flash('exists'); return redirect(url_for('register'))
  u=User(username=request.form['username']); u.set_password(request.form['password']); db.session.add(u); db.session.commit(); return redirect(url_for('login'))
 return render_template('register.html')
@app.route('/login',methods=['GET','POST'])
def login():
 if request.method=='POST':
  u=User.query.filter_by(username=request.form['username']).first()
  if u and u.verify_password(request.form['password']): 
    session['user_id']=u.id;
    app.logger.info(
      "User login: %s",
      u,
      extra={"remote_addr": request.remote_addr}
    )
    return redirect('/')
  app.logger.warning(
    "Failed login attempt: %s",
    u,
    extra={"remote_addr": request.remote_addr}
  )
 return render_template('login.html')
@app.route('/logout')
def logout(): session.clear(); return redirect('/')
@app.route('/add_to_cart/<int:pid>')
def add_to_cart(pid): c=session.get('cart',[]); c.append(pid); session['cart']=c; return redirect('/cart')
@app.route('/cart')
def cart():
 ids=session.get('cart',[]); items=[p for p in PRODUCTS if p['id'] in ids]; total=sum(i['price'] for i in items); return render_template('cart.html',items=items,total=total)
@app.route('/checkout',methods=['GET','POST'])
def checkout():
 u=current_user();
 if not u: return redirect('/login')
 ids=session.get('cart',[]); items=[p for p in PRODUCTS if p['id'] in ids]; total=sum(i['price'] for i in items)
 if request.method=='POST':
  app.logger.info(
    "Order created user=%s total=%.2f order_id=%s",
    current_user().username,
    total,
    order.id,
    extra={"remote_addr": request.remote_addr}
  )
  db.session.add(Order(user_id=u.id,total=total,items=', '.join(i['name'] for i in items))); db.session.commit(); session['cart']=[]; return redirect('/orders')
 return render_template('checkout.html',items=items,total=total)
@app.route('/orders')
def orders():
 u=current_user();
 if not u:return redirect('/login')
 return render_template('orders.html',orders=Order.query.filter_by(user_id=u.id).all())
@app.route('/admin/login',methods=['GET','POST'])
def admin_login():
 if request.method=='POST':
  if request.form['username']=='admin' and request.form['password']=='admin123': 
    session['admin']=True; 
    app.logger.info(
      "Admin login",
      extra={"remote_addr": request.remote_addr}
    )
    return redirect('/admin')
  app.logger.info(
    "Admin login failed",
    extra={"remote_addr": request.remote_addr}
  )
 return render_template('admin/login.html')
@app.route('/admin')
def admin():
 if not session.get('admin'): return redirect('/admin/login')
 return render_template('admin/dashboard.html')
@app.route('/admin/users')
def admin_users():
 if not session.get('admin'): return redirect('/admin/login')
 return render_template('admin/users.html',users=User.query.all())
@app.route('/admin/orders')
def admin_orders():
 if not session.get('admin'): return redirect('/admin/login')
 return render_template('admin/orders.html',orders=Order.query.all())
if __name__=='__main__': app.run(host='0.0.0.0',port=5000)
